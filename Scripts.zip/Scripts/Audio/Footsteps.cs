using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Footsteps : MonoBehaviour
{
    public CharacterController2D controller;
    public Rigidbody2D playerRb;

    public AudioClip footstep1;
    public AudioClip waterStep1;
    public AudioClip waterStep2;
    public AudioClip waterStep3;

    //private float next;

    bool shouldPlay = false;
    int randomizer = 1;

    private void Update()
    {
        StartCoroutine(ShouldPlay());

        if(Puddle.Instance != null)
        {
            if (Puddle.Instance.isBuffed)
            {
                WaterStep();
            }
            else
            {
                NormalStep();
            }
        }

        if (shouldPlay)
        {
            StartCoroutine(PlayStep());
        }
        
    }

    void WaterStep()
    {
        randomizer = Random.Range(1, 3);
        AudioManager.instance.SetSoundPitch("footstep", Random.Range(0.7f, 1.2f));
        AudioManager.instance.SetSoundVolume("footstep", Random.Range(0.3f, 0.5f));

        if (randomizer == 1 && AudioManager.instance.IsSoundPlaying("footstep") == false)
        {
            AudioManager.instance.SetSoundClip("footstep", waterStep1);
        }
        else if (randomizer == 2 && AudioManager.instance.IsSoundPlaying("footstep") == false)
        {
            AudioManager.instance.SetSoundClip("footstep", waterStep2);
        }
        else if (randomizer == 2 && AudioManager.instance.IsSoundPlaying("footstep") == false)
        {
            AudioManager.instance.SetSoundClip("footstep", waterStep3);
        }
    }

    public void NormalStep ()
    {
        AudioManager.instance.SetSoundClip("footstep", footstep1);
        AudioManager.instance.SetSoundPitch("footstep", Random.Range(0.7f, 1.2f));
        AudioManager.instance.SetSoundVolume("footstep", Random.Range(0.25f, 0.35f));
    }

    IEnumerator ShouldPlay()
    {
        if (controller.m_Grounded && playerRb.velocity.magnitude > 4f && playerRb.velocity.y < 0.1f && AudioManager.instance.IsSoundPlaying("footstep") == false)
        {
            shouldPlay = true;
        }
        else
        {
            yield return new WaitForSeconds(0.28f);
            shouldPlay = false;
        }
            
    }

    IEnumerator PlayStep()
    {
        yield return new WaitForSeconds(0.01f);
        AudioManager.instance.PlaySound("footstep");
    }

}
