using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "SaveState", menuName = "SaveState")]
public class SaveState : ScriptableObject
{
    public bool isActiveState;
    public bool hasSavedData;

    public Vector2 playerPositionOnSave;
    public Vector2 lastCheckpointPos;

    public int health;
    public int level;
    public int ammo;
    public int healthAbilities;
    //public float radiationExposure;

    [Header("Dialogue Answers")]

    public bool testAnswer1;
    public bool testAnswer2;
    public bool testAnswer3;


    public void setActiveState(bool active)
    {
        isActiveState = active;
        if(active)
        {
            hasSavedData = true;
        }
    }

}
