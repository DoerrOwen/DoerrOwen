using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Keybindings", menuName = "Keybindings")]
public class Keybindings : ScriptableObject
{
    public KeyCode jump, shoot, switchWeapon, heal, crouch, weapon1, weapon2, weapon3, pause;
    private string[] names = new string[] { "Jump", "Shoot", "SwitchWeapon", "Heal", "Crouch", "Weapon1", "Weapon2",
    "Weapon3", "Pause"};

    public string[] getNames()
    {
        return names;
    }

    public KeyCode CheckKey(string key)
    {
        switch (key)
        {
            case "Jump":
                return jump;
            case "Shoot":
                return shoot;
            case "SwitchWeapon":
                return switchWeapon;
            case "Heal":
                return heal;
            case "Crouch":
                return crouch;
            case "Weapon1":
                return weapon1;
            case "Weapon2":
                return weapon2;
            case "Weapon3":
                return weapon3;
            case "Pause":
                return pause;

            default:
                Debug.Log("a key binding isn't set");
                return KeyCode.None;
        }
    }

    public void SetKey(string key, KeyCode input)
    {
        switch (key)
        {
            case "Jump":
                jump = input;
                break;
            case "Shoot":
                shoot = input;
                break;
            case "SwitchWeapon":
                switchWeapon = input;
                break;
            case "Heal":
                heal = input;
                break;
            case "Crouch":
                crouch = input;
                break;
            case "Weapon1":
                weapon1 = input;
                break;
            case "Weapon2":
                weapon2 = input;
                break;
            case "Weapon3":
                weapon3 = input;
                break;
            case "Pause":
                pause = input;
                break;

            default:
                Debug.Log("a key binding isn't set");
                break;
        }
    }

}
