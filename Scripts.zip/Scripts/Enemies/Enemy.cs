﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float maxHealth = 100f;
    float currentHealth = 100f;

    public Collider2D enemyCollider;

    //public GameObject deathEffect;

    void Start()
    {
        currentHealth = maxHealth;
    }

    public void TakeDamage(float damage)
    {
        currentHealth -= damage;
        //play hurt animation

        if(currentHealth <= 0)
        {
            Die();
        } 
    }
    void Die()
    {
      //Instantiate(deathEffect, transform.position, Quaternion.identity);
      //Play death animation
        Destroy(gameObject);
    }
}
