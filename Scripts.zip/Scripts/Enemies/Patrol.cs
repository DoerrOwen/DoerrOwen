using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol : MonoBehaviour
{
    public float speed;
    public float distance;
    [HideInInspector] public bool movingRight = true;
    public Transform groundDetection;
    public Rigidbody2D rb;
    private Rigidbody2D playerRb;
    public float stoppingDistance = 10f;
    public float retreatDistance = 5f;
    bool isGrounded = false;
    [HideInInspector] public bool playerInRange = false;
    public LayerMask groundLayer;

    public GameObject EnemyGun;
    public Transform radiation;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerRb = GameObject.FindGameObjectWithTag("Player").GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        if(isGrounded)
        {
            DownFlip();
        }

        MoveTowardsPuddle();

    }

    private void Update()
    {
        Draw();
        isGrounded = Physics2D.OverlapCircle(groundDetection.position, 0.2f, groundLayer);

        if(isGrounded == false)
        {
            Flipper();
        }

        //Player Detection//
        if(Vector2.Distance(rb.position, playerRb.position) < stoppingDistance)
        {
            playerInRange = true;
        }
        else if(Vector2.Distance(rb.position, playerRb.position) > stoppingDistance)
        {
            playerInRange = false;
        }
    }

    public void DownFlip()
    {
        if(playerInRange && Vector2.Distance(rb.position, playerRb.position) > retreatDistance)
        {
            transform.position = this.transform.position;
        }
        else if(Vector2.Distance(rb.position, playerRb.position) < retreatDistance)
        {
            transform.position = Vector2.MoveTowards(transform.position, playerRb.position, -speed * Time.deltaTime);
            transform.position = Vector2.Lerp(transform.position, playerRb.position, -speed * Time.deltaTime);
        }
        else
        {
            transform.Translate(Vector2.right * speed * Time.deltaTime);
        }

        RaycastHit2D groundInfo = Physics2D.Raycast(groundDetection.position, Vector2.down, distance);

        if (groundInfo.collider == false)
        {
            Flipper();
        }

    }

    public void Flipper()
    {
        if (movingRight)
        {
            transform.eulerAngles = new Vector3(0, -180, 0);
            movingRight = false;
        }
        else
        {
            transform.eulerAngles = new Vector3(0, 0, 0);
            movingRight = true;
        }
    }

    public void Draw()
    {
        if(playerInRange)
        {
            EnemyGun.SetActive(true);
        }
        else
        {
            EnemyGun.SetActive(false);
        }
    }



    void MoveTowardsPuddle()
    {
        if(isGrounded == false && playerInRange == false)
        {
            if(radiation != null)
            {
                transform.position = Vector2.MoveTowards(transform.position, radiation.position, speed * Time.deltaTime);
                transform.position = Vector2.Lerp(transform.position, radiation.position, speed * Time.deltaTime);
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Flipper();
        }
    }
}
