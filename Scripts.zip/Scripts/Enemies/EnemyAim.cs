using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAim : MonoBehaviour
{
    private Patrol patrol;
    public Rigidbody2D rb;
    private Rigidbody2D playerRb;
    public Transform firePoint;
    public GameObject enemyBullet;

    public float fireRate;
    float nextShot;

    public float accuracyRange = 1.1f;
    //public GameObject muzzleFlash;

    void Start()
    {
        patrol = GetComponentInParent<Patrol>();
        nextShot = fireRate;
        playerRb = GameObject.FindGameObjectWithTag("Player").GetComponent<Rigidbody2D>();
    }


    void Update()
    {
        if (playerRb.position.x < rb.position.x && patrol.movingRight)
        {
            patrol.Flipper();
        }
        else if (playerRb.position.x > rb.position.x && patrol.movingRight == false)
        {
            patrol.Flipper();
        }

        ////////
        
        Vector2 aimDir = playerRb.position - rb.position;
        float angle = Mathf.Atan2(aimDir.y, aimDir.x) * Mathf.Rad2Deg;
        angle += Random.Range(-accuracyRange, accuracyRange);
        transform.rotation = Quaternion.Euler(new Vector3(0f, 0f, angle));

        StartCoroutine(ShootPlayer());
    }

    IEnumerator ShootPlayer()
    {
        Vector3 firePosition = new Vector3(firePoint.position.x, firePoint.position.y, 0f);
        if(Time.time > nextShot)
        {
            nextShot = Time.time + fireRate;
            yield return new WaitForSeconds(0.24f);
            Instantiate(enemyBullet, firePosition, firePoint.rotation);
            yield return new WaitForSeconds(0.24f);
            Instantiate(enemyBullet, firePosition, firePoint.rotation);
        }
    }

}
