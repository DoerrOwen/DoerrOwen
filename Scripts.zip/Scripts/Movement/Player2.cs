﻿    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;

    public class Player2 : MonoBehaviour
    {
    public CharacterController2D controller;
    private Rigidbody2D rb;
    public Animator animator;

    float horizontalMove = 0f;
    public float speedMultiplier;

    bool jump = false;
    bool crouch = false;

    public float gravityWhileDrifted;
    public float driftCooldown = 0;
    public float driftTime = 0;
    public float driftPower = -30f;
    private float nextDrift;
    private float drift = 0f;
    bool isDrifting = false;

    public Transform bookPoint;

    ///////////
    public void setDriftTime(float newDriftTime)
    {
    driftTime = newDriftTime;
    }
    public void setDriftCooldown(float newDriftCooldown)
    {
    driftCooldown = newDriftCooldown;
    }
    public void setDriftPower(float newDriftPower)
    {
    driftPower = newDriftPower;
    }
    public void setSpeed(float newSpeed)
    {
    speedMultiplier = newSpeed;
    }
    /////
    public float getDriftTime()
    {
    return driftTime;
    }
    public float getDriftCooldown()
    {
    return driftCooldown;
    }
    public float getDriftPower()
    {
    return driftPower;
    }
    public float getSpeed()
    {
    return speedMultiplier;
    }
    /////

    // Start is called before the first frame update
    void Start() {
        rb = GetComponent<Rigidbody2D>(); //rb.gravityScale
        rb.gravityScale = 4;

    }

    // Update is called once per frame
    void Update() {

        drift += Time.deltaTime;

        horizontalMove = Input.GetAxisRaw("Horizontal") * speedMultiplier;

        if(Input.GetButtonDown("Jump")) {
            jump = true;
        }

        if(Time.time > nextDrift) {
            if(Input.GetButtonDown("Jump") && isGrounded() == false) {
                drift = 0;
                rb.gravityScale *= gravityWhileDrifted;
                nextDrift = Time.time + driftCooldown;
                Debug.Log("drifting");
                isDrifting = true;
                rb.AddForce(new Vector2(0f, driftPower));

            }
        }


        if(drift > driftTime && isDrifting) {
            isDrifting = false;
            drift = 0;
        }

        if(isDrifting == false) {
            rb.gravityScale = 4;
        }

        if(isGrounded() == true) {
            rb.gravityScale = 4;
            isDrifting = false;
        }
        if(Input.GetButtonUp("Jump") && isGrounded() == false) {
            rb.gravityScale = 4;
            isDrifting = false;
        }


        if(Input.GetButtonDown("Crouch")) {
            crouch = true;
        } else if (Input.GetButtonUp("Crouch")) {
            crouch = false;
        }

    }

    void FixedUpdate() {
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
        jump = false;

    }

    public bool isGrounded() {
        return controller.m_Grounded;
    }

       
    }
