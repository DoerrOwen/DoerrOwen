using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class RopeControl : MonoBehaviour
{
    public CharacterController2D controller;
    public Rope rope;
    public Rigidbody2D rb;
    public GameObject endLinePt;

    //public float zoomOutDuration = 0.5f;
    //public float zoomInDuration = 0.5f;
    //float timeElapsed;
    //float timeElapsed2;

    public float speed = 3f;

    private void Update()
    {

        if(rope.enabled)
        {
            endLinePt.SetActive(true);
            controller.setAirControl(false);
            rb.drag = 0.38f;
        }
        else
        {
            endLinePt.SetActive(false);
            if (controller.m_Grounded)
            {
                controller.setAirControl(true);
                rb.drag = 0.0f;
            }
        }

    }

    void FixedUpdate()
    {
        float h = Input.GetAxisRaw("Horizontal");

        if(rope.enabled)
        {
            rb.AddForce(new Vector2(h * Time.deltaTime * speed, 0f));
        }
    }



}
//CAMERA ZOOM OUT

//   if(timeElapsed < zoomOutDuration)
//   {
//      vcam.m_Lens.OrthographicSize = Mathf.Lerp(11, 15, timeElapsed / zoomOutDuration);
//      timeElapsed += Time.deltaTime;
//  }

//CAMERA ZOOM BACK IN
//  if (timeElapsed2 < zoomInDuration)
// {
//      vcam.m_Lens.OrthographicSize = Mathf.Lerp(15, 11, timeElapsed2 / zoomInDuration);
//      timeElapsed2 += Time.deltaTime;
//  }