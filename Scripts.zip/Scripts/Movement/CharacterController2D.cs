using UnityEngine;
using UnityEngine.Events;

public class CharacterController2D : MonoBehaviour
{
	[SerializeField] public float m_JumpForce = 400f;							
	[Range(0, 1)] [SerializeField] private float m_CrouchSpeed = .36f;			
	[Range(0, .3f)] [SerializeField] private float m_MovementSmoothing = .05f;	
	[SerializeField] private bool m_AirControl = false;							
	[SerializeField] private LayerMask m_WhatIsGround;							
	[SerializeField] private Transform m_GroundCheck;							
	[SerializeField] private Transform m_CeilingCheck;							
	[SerializeField] private Collider2D m_CrouchDisableCollider;               
	[SerializeField] private float slopeCheckDistance;

	const float k_GroundedRadius = .2f; 
	public bool m_Grounded;            
	const float k_CeilingRadius = .2f; 
	[HideInInspector] public Rigidbody2D m_Rigidbody2D;
	public bool m_FacingRight = true;  //use in playerAim
	[HideInInspector]public Vector3 m_Velocity = Vector3.zero;

	//stuff for slope movement
	private CapsuleCollider2D cc;
	private Vector2 colliderSize;
	private float slopeDownAngle;
	private Vector2 slopeNormalPerp;
	public bool isOnSlope;
	private float slopeDownAngleOld;
	private float slopeSideAngle;
	private float xInput;
	[SerializeField] private PhysicsMaterial2D noFriction;
	[SerializeField] private PhysicsMaterial2D fullFriction;

	[Header("Events")]
	[Space]

	public UnityEvent OnLandEvent;

	[System.Serializable]
	public class BoolEvent : UnityEvent<bool> { } 

	public BoolEvent OnCrouchEvent;
	private bool m_wasCrouching = false;

	public void setAirControl(bool newValue)
    {
		m_AirControl = newValue;
    }

    private void Start() {
		cc = GetComponent<CapsuleCollider2D>();
        colliderSize = cc.size;
    }

    private void Awake()
	{
		m_Rigidbody2D = GetComponent<Rigidbody2D>();

		if (OnLandEvent == null)
			OnLandEvent = new UnityEvent();

		if (OnCrouchEvent == null)
			OnCrouchEvent = new BoolEvent();
	}

    private void Update()
    {
		getInput();
    }

    private void FixedUpdate()
	{
		SlopeCheck();
		bool wasGrounded = m_Grounded;
		m_Grounded = false;

		Collider2D[] colliders = Physics2D.OverlapCircleAll(m_GroundCheck.position, k_GroundedRadius, m_WhatIsGround);
		for (int i = 0; i < colliders.Length; i++)
		{
			if (colliders[i].gameObject != gameObject)
			{
				m_Grounded = true;
				if (!wasGrounded)
					OnLandEvent.Invoke();
			}
		}
	}


	public void Move(float move, bool crouch, bool jump)
	{
		if (!crouch)
		{
			if (Physics2D.OverlapCircle(m_CeilingCheck.position, k_CeilingRadius, m_WhatIsGround))
			{
				crouch = true;
			}
		}

		//only control the player if grounded or airControl is turned on AND if they arent on a slope
		if (m_Grounded || m_AirControl && !isOnSlope)
		{

			if (crouch) //crouch
			{
				if (!m_wasCrouching)
				{
					m_wasCrouching = true;
					OnCrouchEvent.Invoke(true);
				}


				move *= m_CrouchSpeed;

				if (m_CrouchDisableCollider != null)
					m_CrouchDisableCollider.enabled = false;

			} else
			{
				if (m_CrouchDisableCollider != null)
					m_CrouchDisableCollider.enabled = true;

				if (m_wasCrouching)
				{
					m_wasCrouching = false;
					OnCrouchEvent.Invoke(false);
				}
			}

			Vector3 targetVelocity = new Vector2(move * 10f, m_Rigidbody2D.velocity.y);
			m_Rigidbody2D.velocity = Vector3.SmoothDamp(m_Rigidbody2D.velocity, targetVelocity, ref m_Velocity, m_MovementSmoothing);

			if (move > 0 && !m_FacingRight)
			{
			//	Flip();
			}
			else if (move < 0 && m_FacingRight)
			{
			//	Flip();
			}
		}
		else if(m_Grounded || m_AirControl && isOnSlope)
        {
			Vector3 targetVelocity = new Vector2(move * slopeNormalPerp.x * -xInput, move * slopeNormalPerp.y * -10f);
			m_Rigidbody2D.velocity = Vector3.SmoothDamp(m_Rigidbody2D.velocity, targetVelocity, ref m_Velocity, m_MovementSmoothing);
			/////
			if (move > 0 && !m_FacingRight)
			{
				Flip();
			}
			else if (move < 0 && m_FacingRight)
			{
				Flip();
			}
			/////
			if (crouch)
			{
				if (!m_wasCrouching)
				{
					m_wasCrouching = true;
					OnCrouchEvent.Invoke(true);
				}
				move *= m_CrouchSpeed;

				if (m_CrouchDisableCollider != null)
					m_CrouchDisableCollider.enabled = false;
			}
			else
			{
				if (m_CrouchDisableCollider != null)
					m_CrouchDisableCollider.enabled = true;

				if (m_wasCrouching)
				{
					m_wasCrouching = false;
					OnCrouchEvent.Invoke(false);
				}
			}

		}

		if (m_Grounded && jump)
		{
			m_Grounded = false;
			m_Rigidbody2D.AddForce(new Vector2(0f, m_JumpForce));
		}



	}

	private void getInput()
    {
		xInput = Input.GetAxisRaw("Horizontal");
    }

	private void SlopeCheck() 
    {
		Vector2 checkPos = transform.position - new Vector3(0.0f, colliderSize.y / 2);

		SlopeCheckHoriztontal(checkPos);
		SlopeCheckVertical(checkPos);
    }

	private void SlopeCheckHoriztontal(Vector2 checkPos)
    {
		RaycastHit2D slopeHitFront = Physics2D.Raycast(checkPos, transform.right, slopeCheckDistance, m_WhatIsGround);
		RaycastHit2D slopeHitBack = Physics2D.Raycast(checkPos, -transform.right, slopeCheckDistance, m_WhatIsGround);

		if(slopeHitFront)
        {
			isOnSlope = true;
			slopeSideAngle = Vector2.Angle(slopeHitFront.normal, Vector2.up);
        }
		else if(slopeHitBack)
        {
			isOnSlope = true;
			slopeSideAngle = Vector2.Angle(slopeHitBack.normal, Vector2.up);
		}
		else
        {
			slopeSideAngle = 0.0f;
			isOnSlope = false;
        }
	}

	private void SlopeCheckVertical(Vector2 checkPos)
	{
		RaycastHit2D hit = Physics2D.Raycast(checkPos, Vector2.down, slopeCheckDistance, m_WhatIsGround);

		if(hit)
        {
			slopeNormalPerp = Vector2.Perpendicular(hit.normal).normalized;

			slopeDownAngle = Vector2.Angle(hit.normal, Vector2.up);

			if(slopeDownAngle != slopeDownAngleOld)
            {
				isOnSlope = true;
            }

			slopeDownAngleOld = slopeDownAngle;

//			Debug.DrawRay(hit.point, hit.normal, Color.green);
        }
		if (isOnSlope && xInput == 0.0f)
        {
			m_Rigidbody2D.sharedMaterial = fullFriction;
        }
		else
        {
			m_Rigidbody2D.sharedMaterial = noFriction;
        }
	}

    public void Flip()
	{
		m_FacingRight = !m_FacingRight;

		transform.Rotate(0f, 180f, 0f);
	}
}