﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player1 : MonoBehaviour
{
    public CharacterController2D controller;
    private Rigidbody2D rb;

    float horizontalMove = 0f;
    public float speedMultiplier = 40f;
    public float airSpeedReducer = 7f;
    public float jumpSpeedOne;
    public float jumpSpeedTwo;

    bool jump = false;
    bool crouch = false;
    private bool canDoubleJump;

    private void Awake() {
        rb = transform.GetComponent<Rigidbody2D>();
    }


    // Start is called before the first frame update
    void Start() {

    }

    // Update is called once per frame
    void Update() {

        if (isGrounded() == false && Input.GetButtonDown("Fire1"))
        {
            canDoubleJump = false;
        }
        else if(isGrounded()) {
            canDoubleJump = true;
        }

        if(Input.GetKeyDown(KeyCode.Space)) {
            if(isGrounded()) {
                float jumpVelocity = jumpSpeedOne;
                rb.velocity = Vector2.up * jumpVelocity;
            } else {
                if(canDoubleJump) {
                    float jumpVelocity = jumpSpeedTwo;
                    rb.velocity = Vector2.up * jumpVelocity;
                    canDoubleJump = false;
                }
            }
        }



        if(Input.GetButtonDown("Crouch")) {
            crouch = true;
        } else if (Input.GetButtonUp("Crouch")) {
            crouch = false;
        }

        if(isGrounded() == false) {
            horizontalMove = Input.GetAxisRaw("Horizontal") * (speedMultiplier - airSpeedReducer);
        } else {
            horizontalMove = Input.GetAxisRaw("Horizontal") * speedMultiplier;
        }

    }

    void FixedUpdate() {
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
        jump = false;
        ////
    }

    public bool isGrounded() {
        return controller.m_Grounded;
    }

    public void setMoveSpeed(float newSpeed)
    {
        speedMultiplier = newSpeed;
    }

}
