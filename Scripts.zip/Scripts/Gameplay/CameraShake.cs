using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CameraShake : MonoBehaviour
{
    public static CameraShake Instance { get; private set; }

    public CinemachineVirtualCamera vcam1;
    public CinemachineVirtualCamera vcam2;
    private float shakeTimer;

    float timeElapsed = 0;

    CinemachineBasicMultiChannelPerlin cbm1;
    CinemachineBasicMultiChannelPerlin cbm2;

    private bool shaker = false;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        cbm1 = vcam1.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>();
        cbm2 = vcam2.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>();
    }

    public void ShakeCamera(float intensity, float fadeDuration, float time)
    {
        shakeTimer = time;
        ShakeCamera(intensity, fadeDuration, shaker);
    }

    public void ShakeCamera(float intensity, float fadeDuration, bool shouldShake)
    {
        float finIntensity = intensity;
        if(shouldShake)
        {
            if(timeElapsed < fadeDuration)
            {
                intensity = Mathf.Lerp(0, finIntensity, timeElapsed / fadeDuration);
                timeElapsed += Time.deltaTime;
            }
            else
            {
                intensity = finIntensity;
                timeElapsed = fadeDuration;
            }

            cbm1.m_AmplitudeGain = intensity;
            cbm2.m_AmplitudeGain = intensity;

            cbm1.m_FrequencyGain = 1;
            cbm2.m_FrequencyGain = 1;
        }
        else
        {
            timeElapsed = 0f;

            cbm1.m_AmplitudeGain = 0f;
            cbm2.m_AmplitudeGain = 0f;

            cbm1.m_FrequencyGain = 0;
            cbm2.m_FrequencyGain = 0;
        }
    }

    private void Update()
    {
        if(shakeTimer > 0)
        {
            shaker = true;
            shakeTimer -= Time.deltaTime;
            if (shakeTimer <= 0f)
            {
                shaker = false;
            }
        }
    }
}
