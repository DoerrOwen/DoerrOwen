using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crosshair : MonoBehaviour
{

    Vector2 mousePos;
    public Camera cam;
    public Rope rope;
    public Transform endRopePoint;
    public CharacterController2D controller;

    private void Start()
    {
       Cursor.visible = false;
    }

    void Update()
    {

        mousePos = cam.ScreenToWorldPoint(Input.mousePosition);

        if(rope.enabled && controller.m_Grounded == false)
        {
            transform.localScale = new Vector3(0, 0, 0);
            Cursor.lockState = CursorLockMode.Locked;
            transform.position = endRopePoint.position;
        }
        else
        {
            transform.localScale = new Vector3(0.2f, 0.2f, 0);
            Cursor.lockState = CursorLockMode.None;
            transform.position = mousePos; 
        }
    }
}
