using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Puddle : MonoBehaviour
{
    public static Puddle Instance { get; private set; }

    private Player3 player;
    private CharacterController2D controller;
    private GunShoot gun;
    private RopeControl ropeController;

    public bool isBuffed = false;
    [HideInInspector] public float timer = 0;

    private float chromatic = 0;
    private float saturation = -29;

    private float speedMultiplier = 45;
    private float jumpForce = 525;
    private float fireRate = 0.18f;
    private float ropeSpeed = 475f;

    public UnityEngine.Rendering.VolumeProfile volumeProfile;

    private void Awake()
    {
        Instance = this;

        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player3>();
        controller = GameObject.FindGameObjectWithTag("Player").GetComponent<CharacterController2D>();
        ropeController = GameObject.FindGameObjectWithTag("Player").GetComponent<RopeControl>();
        gun = GameObject.FindGameObjectWithTag("Player").GetComponentInChildren<GunShoot>();
    }

    private void Update()
    {
      
        if(isBuffed)
        {
            Buff();
            timer += Time.deltaTime;
            if(timer >= 4)
            {
                timer = 4;
            }

            chromatic += Time.deltaTime * 0.53f;
            if (chromatic >= 0.55f)
            {
                chromatic = Random.Range(0.49f, 0.55f);
            }
            saturation += Time.deltaTime * 35.5f;
            if (saturation >= 10f)
            {
                saturation = 10f;
            }

            ///////////
            
            speedMultiplier += Time.deltaTime * 18f;
            if(speedMultiplier >= 60)
            {
                speedMultiplier = 60;
            }
            jumpForce += Time.deltaTime * 125f;
            if(jumpForce >= 725)
            {
                jumpForce = 725;
            }
            fireRate -= Time.deltaTime * 0.31f;
            if(fireRate <= 0.15f)
            {
                fireRate = 0.15f;
            }
            ropeSpeed += Time.deltaTime * 42f;
            if(ropeSpeed >= 535f)
            {
                ropeSpeed = 535f;
            }
        }
        else
        {
            StartCoroutine(DisableBuff());
        }

    }

    private void FixedUpdate()
    {
        BuffEffect();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(Health.instance.getRadDamageTaken() == 0)
        {
            Health.instance.setHealthOnRad(Health.instance.getCurrentHealth());
        }

        if(collision.gameObject.tag == "Player")
        {
            isBuffed = true;
        }
        else
        {
            isBuffed = false;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            isBuffed = false;
        }
    }

    public void Buff()
    {
        player.speedMultiplier = speedMultiplier;
        controller.m_JumpForce = jumpForce;
        gun.fireRate = fireRate;
        ropeController.speed = ropeSpeed;
    }

    public IEnumerator DisableBuff()
    {
        yield return new WaitForSeconds(timer);
        //timer = 0;


        player.speedMultiplier = 45;
        controller.m_JumpForce = 525;
        gun.fireRate = 0.18f;
        ropeController.speed = 475;

        speedMultiplier = 40;
        jumpForce = 525;
        fireRate = 0.18f;
        ropeSpeed = 475f;

        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            timer = 0;
        }

        chromatic -= Time.deltaTime * 0.59f;
        if (chromatic <= 0)
        {
            chromatic = 0;
        }
        saturation -= Time.deltaTime * 35.9f;
        if (saturation <= -29f)
        {
            saturation = -29f;
        }
    }

    public void BuffEffect()
    {
        CameraShake.Instance.ShakeCamera(0.5f, 0.2f, isBuffed);
        //Chromatic//
        UnityEngine.Rendering.Universal.ChromaticAberration chrom;
        if (!volumeProfile.TryGet(out chrom)) throw new System.NullReferenceException(nameof(chrom));

        chrom.intensity.Override(chromatic);
        //Color Adjustment: Saturation//
        UnityEngine.Rendering.Universal.ColorAdjustments colorAdjustments;
        if (!volumeProfile.TryGet(out colorAdjustments)) throw new System.NullReferenceException(nameof(colorAdjustments));

        colorAdjustments.saturation.Override(saturation);
        //Bloom: Threshold//
        UnityEngine.Rendering.Universal.Bloom bloom;
        if (!volumeProfile.TryGet(out bloom)) throw new System.NullReferenceException(nameof(bloom));

        bloom.threshold.Override(0.33f);
        ////////////////////
    }

    private void OnApplicationQuit() //Resets all values back to their starting point when game quits.
    {
        UnityEngine.Rendering.Universal.ChromaticAberration chrom;
        if (!volumeProfile.TryGet(out chrom)) throw new System.NullReferenceException(nameof(chrom));

        chrom.intensity.Override(0);

        UnityEngine.Rendering.Universal.ColorAdjustments colorAdjustments;
        if (!volumeProfile.TryGet(out colorAdjustments)) throw new System.NullReferenceException(nameof(colorAdjustments));

        colorAdjustments.saturation.Override(-29);

        UnityEngine.Rendering.Universal.Bloom bloom;
        if (!volumeProfile.TryGet(out bloom)) throw new System.NullReferenceException(nameof(bloom));

        bloom.threshold.Override(1f);
    }

}
