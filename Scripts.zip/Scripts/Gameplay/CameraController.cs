using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public Animator playerCams;
    public Rope rope;

    public CharacterController2D controller;

    private void Start()
    {
        playerCams.SetBool("zoomedOut", false);
    }

    private void Update()
    {

        if (rope.enabled)
        {
            playerCams.SetBool("zoomedOut", true);
        }
        else
        {
            if (controller.m_Grounded)
            {
                playerCams.SetBool("zoomedOut", false);
            }
        }
    }

}
