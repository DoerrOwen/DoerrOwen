using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ControlsMenu : MonoBehaviour
{
    public static ControlsMenu instance;

    public Keybindings defaultKeybindings;
    public Keybindings keybindings;

    private string[] keyCodes;

    public GameObject keybindTextHolder;
    private Text[] keybindText;

    public GameObject fillHolder;
    private Animator[] fillEffects;

    public GameObject topFillHolder;
    private Animator[] topFillEffects;

    public GameObject selectionCover;

    private KeyCode lastPressed;
    private string key;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(instance);
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    private void Start()
    {
        selectionCover.SetActive(false);
        keyCodes = keybindings.getNames();
        keybindText = keybindTextHolder.GetComponentsInChildren<Text>();
        fillEffects = fillHolder.GetComponentsInChildren<Animator>();
        topFillEffects = topFillHolder.GetComponentsInChildren<Animator>();

        for(int i =0; i < keyCodes.Length; i++)
        {
            keybindText[i].text = keybindings.CheckKey(keyCodes[i]).ToString();
        }
             
    }

    private void Update()
    {
        if(selectionCover.activeSelf)
        {
            foreach (KeyCode vKey in System.Enum.GetValues(typeof(KeyCode)))
            {
                if (Input.GetKey(vKey))
                {
                    lastPressed = vKey;
                    selectionCover.SetActive(false);

                    keybindings.SetKey(key, lastPressed);

                    int index = 0;
                    for (int i = 0; i < keyCodes.Length; i++)
                    {
                        if (keyCodes[i] == key)
                        {
                            index = i;
                        }
                    }

                    SetKeybindText(index, lastPressed.ToString());
                }
            }
        }
    }

    public void SetKeybind(string key)
    {
        selectionCover.SetActive(true);
        this.key = key;
    }

    public void SetKeybindText(int index, string text)
    {
        keybindText[index].text = text;
    }

    public void ResetBinds()
    {
        string[] names = defaultKeybindings.getNames();
        for(int i = 0; i < keyCodes.Length; i++)
        {
            SetKeybindText(i, defaultKeybindings.CheckKey(names[i]).ToString());
            keybindings.SetKey(keyCodes[i], defaultKeybindings.CheckKey(names[i]));
        }
    }

    public void setFill(int i)
    {
        fillEffects[i].SetBool("Fill", true);
    }

    public void setFillFalse(int i)
    {
        fillEffects[i].SetBool("Fill", false);
    }

    public void setTopFill(int i)
    {
        topFillEffects[i].SetBool("Highlight", true);
    }

    public void setTopFillFalse(int i)
    {
        topFillEffects[i].SetBool("Highlight", false);
    }


}
