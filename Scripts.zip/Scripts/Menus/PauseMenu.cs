using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PauseMenu : MonoBehaviour
{
    //pitch down some sounds on pause, do later

    public static PauseMenu instance;

    public static bool GameIsPaused = false;

    public GameObject menuUI;
    public GameObject controlsUI;
    public GameObject settingsUI;

    public GameObject highlightEffectsHolder;
    private Animator[] highlightEffects;

    private GameObject crosshair;

    public Animator healthUIAnimator;

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        menuUI.SetActive(false);
        controlsUI.SetActive(false);
        highlightEffects = highlightEffectsHolder.GetComponentsInChildren<Animator>();
        crosshair = GameObject.FindGameObjectWithTag("Crosshair");
    }

    private void Update()
    {
        if (KeybindingManager.instance.KeyDown("Pause") && controlsUI.activeSelf == false && settingsUI.activeSelf == false)
        {
            if(GameIsPaused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }
        else if(controlsUI.activeSelf && menuUI.activeSelf == false && settingsUI.activeSelf == false)
        {
            if(KeybindingManager.instance.KeyDown("Pause"))
            {
                ControlsBack();
            }
        }
        else if (settingsUI.activeSelf && menuUI.activeSelf == false && controlsUI.activeSelf == false)
        {
            if (KeybindingManager.instance.KeyDown("Pause"))
            {
                SettingsBack();
            }
        }
    }

    public void Resume()
    {
        crosshair.SetActive(true);
        healthUIAnimator.SetBool("HealthOff", false);
        Cursor.visible = false;

        menuUI.SetActive(false);
        Time.timeScale = 1f;
        GameIsPaused = false;

        GameObject.Find("PLAYER").GetComponent<AimFlipper>().enabled = true;
        //GameObject.Find("GunPivot").GetComponent<Aim>().enabled = true;
        //GameObject.Find("GunPivot").GetComponentInChildren<GunShoot>().enabled = true;
    }

    public void Pause()
    {
        crosshair.SetActive(false);
        healthUIAnimator.SetBool("HealthOff", true);
        Cursor.visible = true;

        menuUI.SetActive(true);
        Time.timeScale = 0f;
        GameIsPaused = true;


        GameObject.Find("PLAYER").GetComponent<AimFlipper>().enabled = false;
        //GameObject.Find("GunPivot").GetComponent<Aim>().enabled = false;
        GameObject.Find("GrappleGun").GetComponent<GGun>().Detach();
        //GameObject.Find("GunPivot").GetComponentInChildren<GunShoot>().enabled = false;
        //reset all weird mods of volume profile from radiation
    }

    public void Controls()
    {
        menuUI.SetActive(false);
        controlsUI.SetActive(true);
    }

    public void ControlsBack()
    {
        menuUI.SetActive(true);
        controlsUI.SetActive(false);
    }

    public void Settings()
    {
        menuUI.SetActive(false);
        settingsUI.SetActive(true);
    }

    public void SettingsBack()
    {
        menuUI.SetActive(true);
        settingsUI.SetActive(false);
    }

    public void setHighlight(int i)
    {
        highlightEffects[i].SetBool("Highlight", true);
    }

    public void setHighlightFalse(int i)
    {
        highlightEffects[i].SetBool("Highlight", false);
    }

}
