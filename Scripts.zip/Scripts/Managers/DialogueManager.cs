using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogueManager : MonoBehaviour
{

    private Queue<string> sentences;
    public bool started = false;

    public Text text;
    public Text nameText;
    public Text continueText;
    public Image continueArrow;
    public Image textBox;

    int nameLength;
    public float typeSpeed = 0.07f;
    public bool isYes = false;
    public bool onLastSentence = false;

    [Header("DISABLE ON CONVO")]
    public Player3 playerMovement;
    public RopeControl ropeControl;
    public Aim aimGun;
    public GGun gGun;
    public Rigidbody2D playerRb;
    public AimFlipper aimFlipper;
    public GunShoot gunShoot;

    [Header("Yes / No")]
    public GameObject ynBox;
    public int currentSentence;
    public GameObject crosshair;
    private int sentencesLength;
    private bool hasClicked;
    public Image yesArrow;
    public Image noArrow;

    [Header("Animators")]
    public Animator textBoxAnimator;
    public Animator yesBoxAnimator;
    public Animation boxBackOver;
    public bool canClickBox = true;

    public void SetIsYes(bool value)
    {
        isYes = value;
    }

    public bool SetAnswer(bool input)
    {
        input = isYes;
        return input;
    }

    public void SetHasClicked(bool buttonInput)
    {
        hasClicked = buttonInput;
    }

    public bool GetHasClicked()
    {
        return hasClicked;
    }

    void Start()
    {

        sentences = new Queue<string>();
        
        text.enabled = false;
        textBox.enabled = false;
        nameText.enabled = false;
        continueText.enabled = false;
        continueArrow.enabled = false;
        yesArrow.enabled = false;
        noArrow.enabled = false;

        ynBox.SetActive(false);
    }

    public void StartDialogue(Dialogue dialogue)
    {
        sentencesLength = dialogue.sentences.Length;

        Debug.Log("Starting Conversation With: " + dialogue.name);
        ConvoEnabled();

        nameText.text = dialogue.name + ": ";
        nameLength = nameText.text.Length;

        sentences.Clear();

        foreach(string sentence in dialogue.sentences)
        {
            sentences.Enqueue(sentence);
        }

        DisplayNextSentence();

    }

    public void DisplayNextSentence()
    {
        if(sentences.Count != 0)
        {
            currentSentence = sentencesLength - sentences.Count;
        }

        if(sentences.Count == 1)
        {
            onLastSentence = true;
        }
        else
        {
            onLastSentence = false;
        }

        if (sentences.Count == 0)
        {
            StartCoroutine(WaitEndDialogue());
            return;
        }

        string sentence = sentences.Dequeue();
        StopAllCoroutines();
        StartCoroutine(TypeSentence(sentence));
    }

    IEnumerator TypeSentence(string sentence)
    {
        string spaceString;
        spaceString = AddSpaces(nameLength);
        text.text = spaceString;

        if(sentence[sentence.Length - 1] == '#')
        {
            sentence = sentence.Substring(0, sentence.Length - 1);

            ynBox.SetActive(true);
            textBoxAnimator.SetBool("moveOver", true);
            yesBoxAnimator.SetBool("scrollUp", true);
            continueText.text = "Answer to Continue";

            crosshair.gameObject.SetActive(false);
            Cursor.visible = true;
        }
        else
        {
            StartCoroutine(DisableYesNo());
            textBoxAnimator.SetBool("moveOver", false);
            yesBoxAnimator.SetBool("scrollUp", false);
            continueText.text = "Click to Continue";
        }

        foreach (char letter in sentence.ToCharArray())
        {
            yield return new WaitForSeconds(0.06f);
            text.text += letter;
            yield return null;
        }
    }

    void EndDialogue()
    {
        Debug.Log("End of Conversation");
        ConvoDisabled();
        GameObject.FindGameObjectWithTag("PlayerData").GetComponent<PlayerDataHolder>().SaveAnswers();
    }
    ///////////
    private void ConvoEnabled()
    {
        started = true;
        text.enabled = true;
        textBox.enabled = true;
        nameText.enabled = true;
        continueText.enabled = true;
        continueArrow.enabled = true;

        playerMovement.enabled = false;
        ropeControl.enabled = false;
        aimGun.enabled = false;
        gGun.enabled = false;
        playerRb.velocity = new Vector2(0, 0);
        aimFlipper.enabled = false;
        gunShoot.enabled = false;
    }

    private void ConvoDisabled()
    {
        started = false;
        text.enabled = false;
        textBox.enabled = false;
        nameText.enabled = false;
        continueText.enabled = false;
        continueArrow.enabled = false;
        yesArrow.enabled = false;
        noArrow.enabled = false;

        ynBox.SetActive(false);
        crosshair.gameObject.SetActive(true);
        Cursor.visible = false;

        textBoxAnimator.SetBool("moveOver", false);
        yesBoxAnimator.SetBool("scrollUp", false);

        playerMovement.enabled = true;
        ropeControl.enabled = true;
        aimGun.enabled = true;
        gGun.enabled = true;
        aimFlipper.enabled = true;
        gunShoot.enabled = true;
    }

    IEnumerator WaitEndDialogue()
    {
        textBoxAnimator.SetTrigger("moveDown");
        yield return new WaitForSeconds(0.67f);
        EndDialogue();
        StartCoroutine(WaitToTriggerAgain());
    }

    IEnumerator WaitToTriggerAgain()
    {
        canClickBox = false;
        yield return new WaitForSeconds(2f);
        canClickBox = true;
    }

    private string AddSpaces(int numSpaces)
    {
        string answer = "";
        for(int i = 0; i < numSpaces; i++) {
            answer += " ";
        }
        return answer;
    }

    IEnumerator DisableYesNo()
    {
        yield return new WaitForSeconds(0.9f);
        ynBox.SetActive(false);

        crosshair.gameObject.SetActive(true);
        Cursor.visible = false;
    }

    public void SetYesArrow(bool setting)
    {
        yesArrow.enabled = setting;
    }
    public void SetNoArrow(bool setting)
    {
        noArrow.enabled = setting;
    }

}
