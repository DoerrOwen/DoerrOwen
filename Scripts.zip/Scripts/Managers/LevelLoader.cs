using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelLoader : MonoBehaviour
{
    public Animator transition;
    public float waitBetweenScene = 0.7f;

    public IEnumerator LoadLevel(int levelIndex)
    {
        transition.SetBool("Start", true);

        yield return new WaitForSeconds(waitBetweenScene);

        SceneManager.LoadScene(levelIndex);
    }

    public void LoadNextLevel()
    {
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex + 1));
    }

    public void LoadInputLevel(int input)
    {
        StartCoroutine(LoadLevel(input));
    }

}
