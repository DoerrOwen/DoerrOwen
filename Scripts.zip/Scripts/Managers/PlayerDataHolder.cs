using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerDataHolder : MonoBehaviour
{
    public static PlayerDataHolder instance;

    public SaveState[] SAVESTATES = new SaveState[4];
    private int activeState = 0;

    private Transform playerPos;
    private DialogueTrigger[] dtrigs;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(instance);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        activeState = getActiveSave();

        playerPos = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();

        //ANSWERS//
        dtrigs = GameObject.FindGameObjectWithTag("DialogueTriggers").GetComponentsInChildren<DialogueTrigger>();

        //TEST SAVE(O) AND LOAD(P)//
        if(Input.GetKeyDown(KeyCode.O))
        {
            Save();
        }
        if (Input.GetKeyDown(KeyCode.P))
        {
            Load();
        }

    }

    public void Save()
    {
        SaveSystem.SavePlayer(this);

        SAVESTATES[activeState].playerPositionOnSave = playerPos.position;
        SAVESTATES[activeState].lastCheckpointPos = GameObject.FindGameObjectWithTag("CheckpointManager").GetComponent<CheckpointManager>().GetLastCheckpoint();
        SAVESTATES[activeState].level = SceneManager.GetActiveScene().buildIndex;
        SAVESTATES[activeState].health = GetComponent<Health>().getCurrentHealth();
        SAVESTATES[activeState].ammo = GetComponent<Health>().getCurrentAmmo();
        SAVESTATES[activeState].healthAbilities = GetComponent<Health>().getCurrentAbilities();
    }

    public void SaveAnswers()
    {
        SaveSystem.SavePlayer(this);

        if (SceneManager.GetActiveScene().buildIndex == 0) //SCENE 1
        {
            SAVESTATES[activeState].testAnswer1 = dtrigs[0].dialogue.answers[1];
            SAVESTATES[activeState].testAnswer2 = dtrigs[0].dialogue.answers[2];
            SAVESTATES[activeState].testAnswer3 = dtrigs[0].dialogue.answers[3];
        }
        else if(SceneManager.GetActiveScene().buildIndex == 1) //SCENE 2
        {
            //scene 2 answers...
        }
    }

    public void Load()
    {
        //LOAD PLAYERDATAHOLDER//
        PlayerData data = SaveSystem.LoadPlayer();

        SAVESTATES[activeState].health = data.currentHealth;
        GetComponent<Health>().setCurrentHealth(SAVESTATES[activeState].health);

        SAVESTATES[activeState].level = data.currentLevel;

        SAVESTATES[activeState].ammo = data.ammo;
        GetComponent<Health>().setCurrentAmmo(SAVESTATES[activeState].ammo);

        SAVESTATES[activeState].healthAbilities = data.healthAbilities;
        GetComponent<Health>().setCurrentAbilities(SAVESTATES[activeState].healthAbilities);

        Vector2 loadPosition;
        loadPosition.x = data.position[0];
        loadPosition.y = data.position[1];
        SAVESTATES[activeState].playerPositionOnSave = loadPosition;

        Vector2 checkpointPos;
        checkpointPos.x = data.checkpointPos[0];
        checkpointPos.y = data.checkpointPos[1];
        FindObjectOfType<CheckpointManager>().SetLastCheckpoint(checkpointPos);
        SAVESTATES[activeState].lastCheckpointPos = checkpointPos;

        //ANSWERS//

        SAVESTATES[activeState].testAnswer1 = data.testAnswer1;
        SAVESTATES[activeState].testAnswer2 = data.testAnswer2;
        SAVESTATES[activeState].testAnswer3 = data.testAnswer3;
    }

    public void StartMenuLoad()
    {
        GetComponent<LevelLoader>().LoadInputLevel(SAVESTATES[activeState].level);
    }

    public int getActiveSave()
    {
        int active = 0;
        for(int i = 0; i < SAVESTATES.Length; i++)
        {
            if(SAVESTATES[i].isActiveState)
            {
                active = i;
            }
        }
        return active;
    }

    private void OnApplicationQuit()
    {
        Save();
    }

}
