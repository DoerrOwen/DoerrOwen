using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CheckpointManager : MonoBehaviour
{
    private static CheckpointManager instance;

    public PlayerDataHolder pd;

    public Vector2 lastCheckPointPos;

    private LevelLoader transitionHolder;
    private Animator transition;

    public bool hasEnded = false;
    public float wait = 2f;

    public Vector2 GetLastCheckpoint()
    {
        return lastCheckPointPos;
    }

    public void SetLastCheckpoint(Vector2 pos)
    {
        lastCheckPointPos = pos;
    }

    private void Awake()
    {
        if(instance == null)
        {
            instance = this;
            DontDestroyOnLoad(instance);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        transitionHolder = GameObject.FindGameObjectWithTag("PlayerData").GetComponent<LevelLoader>();
        transition = transitionHolder.transition;
    }

    private void Update()
    {
        //transition
        if(hasEnded)
        {
            transition.SetBool("Start", true);
        }
        else
        {
            transition.SetBool("Start", false);
        }
    }

    public void EndGame()
    {
        if(hasEnded == false)
        {
            Health.instance.setCurrentHealth(8);
            pd.Save();
            hasEnded = true;
            Invoke("Restart", wait);
            StartCoroutine(GameObject.FindGameObjectWithTag("PlayerData").GetComponent<Health>().ResetHealth());
        }
    }

    void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); //if .name doesn't work, use .buildIndex
        hasEnded = false;
    }

}
