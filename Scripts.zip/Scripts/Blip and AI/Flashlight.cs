using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flashlight : MonoBehaviour
{
    public Rigidbody2D homieRb;
    public Rigidbody2D playerRb;

    public float angleOffset = 10f;

    private CharacterController2D controller;

    private int lightRotation = 0;
    private float timeElapsed;

    public Animator animator;

    private void Start()
    {
        controller = GameObject.FindGameObjectWithTag("Player").GetComponent<CharacterController2D>();
    }

    void FixedUpdate()
    {
        Vector2 aimDir = playerRb.position - homieRb.position;
        float angle = Mathf.Atan2(aimDir.y, aimDir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(new Vector3(0f, 0f, angle + angleOffset));
    }

    private void Update()
    {
        if (Time.time > timeElapsed)
        {
            lightRotation = Random.Range(1, 4);
            timeElapsed = Time.time + 0.5f;
        }
        
        if(lightRotation == 3 && controller.m_Grounded)
        {
            animator.SetBool("RandomLight", true);
        }
        else
        {
            animator.SetBool("RandomLight", false);
        }

    }



}
