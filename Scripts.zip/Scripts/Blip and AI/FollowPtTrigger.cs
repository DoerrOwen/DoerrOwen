using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPtTrigger : MonoBehaviour
{
    public static FollowPtTrigger instance;

    public bool blipInRange = false;

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }
        DontDestroyOnLoad(gameObject);
    }

    public bool getBlipInRage()
    {
        return blipInRange;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Blip" )
        {
            blipInRange = true;
        }
        else
        {
            blipInRange = false;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Blip")
        {
            blipInRange = false;
        }
    }

}
