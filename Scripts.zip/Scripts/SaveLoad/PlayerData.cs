using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData
{
    public int currentLevel;
    public int currentHealth;
    public int ammo;
    public int healthAbilities;

    public float[] position;
    public float[] checkpointPos;

    public bool testAnswer1;
    public bool testAnswer2;
    public bool testAnswer3;
    public bool testAnswer4;
    public bool testAnswer5;


    public PlayerData(PlayerDataHolder player)
    {
        currentLevel = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].level;
        currentHealth = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].health;
        ammo = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].ammo;
        healthAbilities = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].healthAbilities;

        position = new float[2];
        position[0] = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].playerPositionOnSave.x;
        position[1] = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].playerPositionOnSave.y;

        checkpointPos = new float[2];
        checkpointPos[0] = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].lastCheckpointPos.x;
        checkpointPos[1] = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].lastCheckpointPos.y;

        //ANSWERS//

        testAnswer1 = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].testAnswer1;
        testAnswer2 = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].testAnswer2;
        testAnswer3 = player.SAVESTATES[PlayerDataHolder.instance.getActiveSave()].testAnswer3;
    }

}
