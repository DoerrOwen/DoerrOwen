using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Illuminate : MonoBehaviour
{
    public GGun gun;
    public GameObject lightHolder;
    public BoxCollider2D col;
    bool ill;

    private void Start()
    {
        lightHolder.gameObject.SetActive(false);
    }

    private void Update()
    {
        ill = gun.ShouldIlluminate(col);

        if (ill)
        {
            lightHolder.gameObject.SetActive(true);
        }
        else
        {
            lightHolder.gameObject.SetActive(false);
        }
    }
}
