using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyFlashes : MonoBehaviour
{

    void Update()
    {
        StartCoroutine(Destroy());
    }

    IEnumerator Destroy()
    {
        yield return new WaitForSeconds(3.5f);
        Destroy(gameObject);
    }

}
