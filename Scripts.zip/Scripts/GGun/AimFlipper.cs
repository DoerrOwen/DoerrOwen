using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AimFlipper : MonoBehaviour
{
    private Vector2 mousePos;
    public Camera cam;
    public Rigidbody2D playerRb;
    public CharacterController2D controller;

    private void Update()
    {
        mousePos = cam.ScreenToWorldPoint(Input.mousePosition);

        if (mousePos.x < playerRb.position.x && controller.m_FacingRight)
        {
            controller.Flip();
        }
        else if (mousePos.x > playerRb.position.x && controller.m_FacingRight == false)
        {
            controller.Flip();
        }
    }
}
