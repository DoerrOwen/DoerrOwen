﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float bulletSpeed = 20f;
    public Rigidbody2D rb;
    public float damage = 50;
    public GameObject impactEffect;
    public float splashRange;
    public bool isEnemyBullet = false;

    [Header("Audio")]
    public AudioClip impact1;
    public AudioClip impact2;
    public AudioClip impact3;
    public AudioClip impact4;
    private int random;

    [Header("Camera Shake")]
    private bool shaker = false;
    public float shakeTime = .18f;
    public float shakeIntensity = 2.1f;

    IEnumerator Shaker(float time)
    {
        shaker = true;
        yield return new WaitForSeconds(time);
        shaker = false;
    }

    private void Awake()
    {
        StartCoroutine(Shaker(shakeTime));
    }

    void Start()
    {
        rb.velocity = transform.right * bulletSpeed;
    }

    private void FixedUpdate()
    {
        StartCoroutine(destroyAfterTime());

        if(isEnemyBullet == false)
        {
            CameraShake.Instance.ShakeCamera(0.9f, 0.0f, shaker);
        }

        //AUDIO//
        if (AudioManager.instance.IsSoundPlaying("impact") == false)
        {
            random = Random.Range(1, 4);
            AudioManager.instance.SetSoundPitch("impact", Random.Range(0.7f, 1.1f));
        }
        /////
        //if (random == 1)
        //{
        //    AudioManager.instance.SetSoundClip("impact", impact1);
        //}
        //else if (random == 2)
        //{
        //    AudioManager.instance.SetSoundClip("impact", impact2);
        //}
        //else if (random == 3)
        //{
        //    AudioManager.instance.SetSoundClip("impact", impact3);
        //}
        //else if (random == 4)
        //{
        //    AudioManager.instance.SetSoundClip("impact", impact4);
        //}
    }

    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        if(isEnemyBullet == false)
        {
            if (splashRange > 0)
            {
                Collider2D[] hitColliders = Physics2D.OverlapCircleAll(transform.position, splashRange);
                foreach (Collider2D hitCollider in hitColliders)
                {
                    Enemy enemy = hitCollider.GetComponent<Enemy>();
                    if (enemy)
                    {
                        Vector3 closestPoint = hitCollider.ClosestPoint(transform.position);
                        float distance = Vector3.Distance(closestPoint, transform.position);

                        float damagePercent = Mathf.InverseLerp(splashRange, 0, distance);
                        enemy.TakeDamage(damage * damagePercent);
                    }
                }
            }
            else
            {
                Enemy enemy = hitInfo.GetComponent<Enemy>();
                if (enemy != null)
                {
                    enemy.TakeDamage(damage);
                }
            }
            //////
            if (hitInfo.gameObject.tag != "Crosshair" && hitInfo.gameObject.tag != "Checkpt"
            && hitInfo.gameObject.tag != "Player" && hitInfo.gameObject.tag != "Blip"
            && hitInfo.gameObject.tag != "DialogueTrigger")
            {
                AudioManager.instance.SetSoundPitch("impact", Random.Range(0.7f, 1.2f));
                AudioManager.instance.SetSoundVolume("impact", Random.Range(0.05f, 0.11f));
                AudioManager.instance.PlaySound("impact");

                Instantiate(impactEffect, transform.position, transform.rotation);
                Destroy(gameObject);
            }
        }

        else

        {
            if (splashRange > 0)
            {
                Collider2D[] hitColliders = Physics2D.OverlapCircleAll(transform.position, splashRange);
                foreach (Collider2D hitCollider in hitColliders)
                {
                    Player3 playerHealth = hitCollider.GetComponent<Player3>();
                    if (playerHealth)
                    {
                        Vector3 closestPoint = hitCollider.ClosestPoint(transform.position);
                        float distance = Vector3.Distance(closestPoint, transform.position);

                        float damagePercent = Mathf.InverseLerp(splashRange, 0, distance);
                        playerHealth.TakeDamage((int)(damage * damagePercent));
                    }
                }
            }
            else
            {
                Player3 playerHealth = hitInfo.GetComponent<Player3>();
                if (playerHealth != null)
                {
                    playerHealth.TakeDamage((int)damage);
                }
            }
            /////
            if (hitInfo.gameObject.tag != "Crosshair" && hitInfo.gameObject.tag != "Checkpt"
            && hitInfo.gameObject.tag != "Enemy" && hitInfo.gameObject.tag != "Blip"
            && hitInfo.gameObject.tag != "DialogueTrigger")
            { 
                Instantiate(impactEffect, transform.position, transform.rotation);
                Destroy(gameObject);
            }
        }
 
    }

    IEnumerator destroyAfterTime()
    {
        yield return new WaitForSeconds(3.5f);
        Destroy(gameObject);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, splashRange);
    }

    public void setBulletDamage(float newDamage)
    {
        damage = newDamage;
    }

}
