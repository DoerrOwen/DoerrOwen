using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Aim : MonoBehaviour
{
    public Camera cam;
    public Vector2 mousePos;
    public float angle;
    public Rigidbody2D rb;
    public CharacterController2D player;

    public Transform gGunTransform;

    bool canShoot = true;
    
    private void Update()
    {
        mousePos = cam.ScreenToWorldPoint(Input.mousePosition);

        if (mousePos.x < rb.position.x && isFacingRight())
        {
            canShoot = false;
        }
        else if (mousePos.x > rb.position.x && isFacingRight() == false)
        {
            canShoot = false;
        } else
        {
            canShoot = true;
        }

        gGunTransform.rotation = transform.rotation;

    }

    public void FixedUpdate()
    {
        Vector2 aimDir = mousePos - rb.position;
        angle = Mathf.Atan2(aimDir.y, aimDir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(new Vector3(0f, 0f, angle));
    }

    bool isFacingRight()
    {
        return player.m_FacingRight;
    }

    public bool getCanShoot()
    {
        return canShoot;
    }

    public void setCanShoot(bool setter)
    {
        canShoot = setter;
    }

}
