using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunShoot : MonoBehaviour
{
    public static GunShoot instance { get; private set; }

    public Transform firePoint;
    public GameObject bullet;
    public GameObject muzzleFlash;
    public float fireRate = 0.1f;
    float nextFire;

    public int maxAmmo;
    private int currentAmmo;
    public float reloadTimeBetweenBullets;

    public float groundedRecoil = 220;
    public float airRecoil = 180;
    private float recoilForce;

    private bool isReloading = false;

    public Aim aim;
    bool canShoot;

    private Rigidbody2D playerRb;

    public int getCurrentAmmo()
    {
        return currentAmmo;
    }

    public int getMaxAmmo()
    {
        return maxAmmo;
    }

    public void setRecoil(float recoil)
    {
        recoilForce = recoil;
    }

    private void Awake()
    {
        instance = this;
    }

    private void Start()
    {
        currentAmmo = maxAmmo;
        playerRb = GameObject.FindGameObjectWithTag("Player").GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        canShoot = aim.getCanShoot();

        if (isReloading)
            return;

        if (KeybindingManager.instance.KeyDown("Shoot") && Time.time > nextFire)
        {
            Shoot();
            nextFire = Time.time + fireRate;
        }
      

        if (Input.GetKeyDown(KeyCode.R))
        {
            StartCoroutine(Reload());
            return;
        }

    }

    void Shoot()
    {
        if(currentAmmo != 0)
        {
            AudioManager.instance.SetSoundPitch("shoot", Random.Range(0.7f, 1.2f));
            AudioManager.instance.SetSoundVolume("shoot", Random.Range(0.2f, 0.4f));
            AudioManager.instance.PlaySound("shoot");

            Vector3 firePosition = new Vector3(firePoint.position.x, firePoint.position.y, 0f);
            GameObject tempBullet = Instantiate(bullet, firePosition, firePoint.rotation);
            Instantiate(muzzleFlash, firePosition, firePoint.rotation);

            Vector3 dir = Quaternion.AngleAxis(aim.angle, Vector3.forward) * Vector3.right;
            GameObject.FindGameObjectWithTag("Player").GetComponent<Player3>().ChangeRecoil(groundedRecoil, airRecoil);
            playerRb.AddForceAtPosition(-dir * recoilForce, firePosition);

            currentAmmo--;
        }
    }

    IEnumerator Reload()
    {
        isReloading = true;

        for (int i = 0; i < maxAmmo; i++)
        {
            if(currentAmmo != maxAmmo)
            {
                yield return new WaitForSeconds(reloadTimeBetweenBullets);
                currentAmmo++;
            }
        }

        isReloading = false;

    }

}


//yield return new WaitForSeconds(anim.GetCurrentAnimatorStateInfo(0).length+anim.GetCurrentAnimatorStateInfo(0).normalizedTime);
//use this to finish draw animation, then shoot. IEnumerator that calls this, then Shoot();