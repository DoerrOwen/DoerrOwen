﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class Player3 : MonoBehaviour {

    public CharacterController2D controller;

    private CheckpointManager checkpointManager;
    private GunShoot gunShoot;

    float horizontalMove = 0f;
    public float speedMultiplier = 40f;
    public float airSpeedReducer = 7f;

    public float fallDamageVelocity = 15f;

    bool jump = false;
    bool crouch = false;

    bool fallDamage = false;

    public CinemachineVirtualCamera vcam;

    // Start is called before the first frame update
    void Start() {
        vcam.GetCinemachineComponent<CinemachineTransposer>();

        checkpointManager = GameObject.FindGameObjectWithTag("CheckpointManager").GetComponent<CheckpointManager>();
        transform.position = checkpointManager.lastCheckPointPos;

        gunShoot = GameObject.FindGameObjectWithTag("Player").GetComponentInChildren<GunShoot>();
    }

    // Update is called once per frame
    void Update() {

        if(KeybindingManager.instance.KeyDown("Jump")) {
            jump = true;
        }

        if(KeybindingManager.instance.KeyDown("Crouch")) {
            crouch = true;
        } else if (KeybindingManager.instance.KeyDown("Crouch")) {
            crouch = false;
        }

        if(isGrounded() == false) {
            horizontalMove = Input.GetAxisRaw("Horizontal") * (speedMultiplier - airSpeedReducer);
        } else {
            horizontalMove = Input.GetAxisRaw("Horizontal") * speedMultiplier;
        }

        //CAMERA EDITING
        if(isGrounded())
        {
            vcam.GetComponent<CinemachineVirtualCamera>().GetCinemachineComponent<CinemachineFramingTransposer>().m_YDamping = 1f;
            vcam.GetComponent<CinemachineVirtualCamera>().GetCinemachineComponent<CinemachineFramingTransposer>().m_XDamping = .3f;
        }
        else
        {
            vcam.GetComponent<CinemachineVirtualCamera>().GetCinemachineComponent<CinemachineFramingTransposer>().m_YDamping = .1f;
            vcam.GetComponent<CinemachineVirtualCamera>().GetCinemachineComponent<CinemachineFramingTransposer>().m_XDamping = .3f;
        }

    }

    void FixedUpdate() {
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
        jump = false;
        ////
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "deathCollider")
        {
            checkpointManager.EndGame();
        }
    }

    public void ChangeRecoil(float groundedRecoil, float airRecoil)
    {
        if (controller.m_Grounded)
        {
            gunShoot.setRecoil(groundedRecoil);
        }
        else
        {
            gunShoot.setRecoil(airRecoil);
        }

    }

    public void FallDamage(bool landed)
    {
        fallDamage = landed;
        if(fallDamage && Mathf.Abs(controller.m_Rigidbody2D.velocity.y) > fallDamageVelocity)
        {
            fallDamage = false;
            //Player take damage
            Debug.Log("Fall Damage"); 
        }
    }

    public void TakeDamage(int damage)
    {
        StartCoroutine(Health.instance.TakeDamage(damage, 0));
    }

    public bool isGrounded() {
        return controller.m_Grounded;
    }
    public float jumpForce() {
        return controller.m_JumpForce;
    }

    public float getAirSpeed()
    {
        return airSpeedReducer;
    }
    public void setAirSpeed(float newSpeed)
    {
        airSpeedReducer = newSpeed;
    }
}
