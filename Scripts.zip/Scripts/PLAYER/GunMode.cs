using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunMode : MonoBehaviour
{
    public GameObject ggun;
    public GameObject normalGun;
    public Rope rope;
    private bool canSwitch;
    public bool gunMode = false;

    private void Update()
    {
        if(rope.enabled)
        {
            canSwitch = false;
        }
        else
        {
            canSwitch = true;
        }

        if(KeybindingManager.instance.KeyDown("SwitchWeapon") && canSwitch)
        {
            gunMode = !gunMode;
        }

        if(gunMode)
        {
            ggun.SetActive(false);
            normalGun.SetActive(true);
        }
        else if(gunMode == false)
        {
            ggun.SetActive(true);
            normalGun.SetActive(false);
        }

    }

}
