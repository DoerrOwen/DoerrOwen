using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{
    public static Health instance;

    [Header("Health")]
    public int currentHealth;
    static int maxHealth = 8; //DONT CHANGE FROM 8!

    [Header("Health Bar UI")]
    public Image[] healthPoints;
    public Sprite[] fullHealthPoint = new Sprite[3];

    public Sprite emptyHealthPoint;
    private int[] fullSpriteSetter;

    private Animator healthUIAnimator;

    [Header("Health Bar Effects")]
    //damage flash
    public Animator damageFlash;
    public UnityEngine.Rendering.VolumeProfile volumeProfile;

    //damage effect overlays
    public Animator[] damageEffects;
    private Image[] damageEffectSprites;
    public Animator[] healthEffects;

    private string damageAnim = "";
    public Material normalDamageMat;

    //radiation damage effect overlays
    public Material radiationDamageMat;
    public GameObject radiationDamageEffectsHolder;
    private Animator[] radiationDamageEffects;

    //radiation damage effect variables
    private int radDamageTaken = 0;
    private int healthOnRad;

    [Header("BulletUI // Effects")]

    public GameObject bulletHolder;
    private Animator[] bullets;
    private Image[] bulletSprites;

    public Material normalBulletGlow;
    public Material intenseBulletGlow;

    private int maxAmmo = 6;
    private int currentAmmo = 0;

    [Header("Health Ability // Effects")]

    public GameObject healthAbilityHolder;
    private Animator[] healthAbilities;

    private int maxAbilities = 5;

    private int healable;
    private int emptyAbilities;

    public int currentAbilities;

    public float timeBetweenHeal = 0.35f;
    public float abilityRegenTime = 10f;

    [Header("Radiation Bar UI")]

    public Slider radBar;

    public void setHealthOnRad(int healthRad)
    {
        healthOnRad = healthRad;
    }

    public int getCurrentHealth()
    {
        return currentHealth;
    }

    public void setCurrentHealth(int newHealth)
    {
        currentHealth = newHealth;
    }

    public void setCurrentAmmo(int ammo)
    {
        currentAmmo = ammo;
    }

    public void setCurrentAbilities(int abilities)
    {
        currentAbilities = abilities;
    }

    public int getRadDamageTaken()
    {
        return radDamageTaken;
    }

    public int getCurrentAbilities()
    {
        return currentAbilities;
    }

    public int getHealable()
    {
        return healable;
    }

    public int getEmptyAbilities()
    {
        return emptyAbilities;
    }

    public int getCurrentAmmo()
    {
        return currentAmmo;
    }

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        fullSpriteSetter = new int[maxHealth];
        bullets = bulletHolder.GetComponentsInChildren<Animator>();
        bulletSprites = bulletHolder.GetComponentsInChildren<Image>();

        maxAbilities = 5;
        currentAbilities = maxAbilities;

        healthAbilities = healthAbilityHolder.GetComponentsInChildren<Animator>();

        healthUIAnimator = GameObject.Find("HealthUICanvas").GetComponent<Animator>();

        for (int i = 0; i < fullSpriteSetter.Length; i++)
        {
            fullSpriteSetter[i] = Random.Range(0, 3);
        }

        for (int i = 0; i < bullets.Length; i++)
        {
            bullets[i].SetBool("BulletFull", true);
        }

    }

    private void Update()
    {
        VignetteHealth();
        RadiationDamage();

        healable = maxHealth - currentHealth;
        emptyAbilities = maxAbilities - currentAbilities;

        if(healable > 5)
        {
            healable = 5;
        }

        if(KeybindingManager.instance.KeyDown("Heal") && radDamageTaken == 0)
        {
            StartCoroutine(healthAbility());
        }

        healthPoints = GameObject.FindGameObjectWithTag("HealthPoints").GetComponentsInChildren<Image>(); //green health points
        healthEffects = GameObject.FindGameObjectWithTag("HealthPoints").GetComponentsInChildren<Animator>(); //animators on green health points
        damageEffects = GameObject.FindGameObjectWithTag("DamageEffects").GetComponentsInChildren<Animator>(); //animators on damage overlays
        damageEffectSprites = GameObject.FindGameObjectWithTag("DamageEffects").GetComponentsInChildren<Image>(); //images of damage overlays, used to set material
        radiationDamageEffects = radiationDamageEffectsHolder.GetComponentsInChildren<Animator>(); //animators for damage lost to radiation

        radBar.value = Puddle.Instance.timer;

        if (Puddle.Instance.timer != 0) //set materials based on radiation/normal
        {
            damageAnim = "RadiationDamageEffect";
            for (int i = 0; i < healthPoints.Length; i++)
            {
                damageEffectSprites[i].material = radiationDamageMat;
            }
        }
        else
        {
            damageAnim = "DamageEffect";
            for (int i = 0; i < healthPoints.Length; i++)
            {
                damageEffectSprites[i].material = normalDamageMat;
            }
        }

        if (currentHealth > maxHealth) //dont let current health go above max health
        {
            currentHealth = maxHealth;
        }

        if(currentAbilities > maxAbilities)
        {
            currentAbilities = maxAbilities;
        }

        for (int i = 0; i < healthPoints.Length; i++) //set health point sprites
        {

            if(i < currentHealth)
            {
                healthPoints[i].sprite = fullHealthPoint[fullSpriteSetter[i]]; //used to randomize the sprite of the health point on regen
            }
            else
            {
                healthPoints[i].sprite = emptyHealthPoint;
            }

            if(i < maxHealth)
            {
                healthPoints[i].enabled = true;
            }
            else
            {
                healthPoints[i].enabled = false;
            }
        }

        if(currentHealth <= 0) //if player has no health, die.
        {
            currentHealth = 0;
            Die();
        }

        currentAmmo = GunShoot.instance.getCurrentAmmo(); //constantly get the current ammo of the player
        maxAmmo = GunShoot.instance.getMaxAmmo(); //and max ammo

        for(int i = 0; i < bullets.Length; i++) 
        {
            if(i < currentAmmo)
            {
                bulletSprites[i].material = normalBulletGlow;
                bullets[i].SetBool("BulletFull", true);
                
            }
            else
            {
                bulletSprites[i].material = intenseBulletGlow; 
                bullets[i].SetBool("BulletFull", false);
            }
        }

        for(int i = 0; i < healthAbilities.Length; i++)
        {
            if(i < currentAbilities)
            {
                healthAbilities[i].SetBool("HealthAbility", true);
            }
            else
            {
                healthAbilities[i].SetBool("HealthAbility", false);
            }
        }

    }

    public IEnumerator TakeDamage(int damage, float wait)
    {
        if(wait == 0)
        {
            wait = 0.02f;
        }

        if(damage > currentHealth)
        {
            currentHealth = 0;
        }
        else
        {
            for (int i = 0; i < damage; i++)
            {
                if (currentHealth != 0)
                {
                    yield return new WaitForSeconds(wait);
                    currentHealth--;
                    healthOnRad--;
                }
                damageFlash.SetTrigger("DamageFlash");
                healthEffects[currentHealth].SetTrigger("LoseHealthPt");
                if(damageAnim == "DamageEffect")
                {
                    damageEffects[currentHealth].SetTrigger(damageAnim);
                }
                else
                {
                    StartCoroutine(radDamEffect());
                }
            }
        }
    }

    public IEnumerator healthAbility()
    {
        int currentAbilitiesOnHeal = getCurrentAbilities();
        int healableOnHeal = getHealable();

        for(int i = 0; i < healableOnHeal; i++)
        {
            if(i < currentAbilitiesOnHeal && healable > 0)
            {
                StartCoroutine(Heal(1, timeBetweenHeal));
                currentAbilities--;
                yield return new WaitForSeconds(timeBetweenHeal);
            }
        }
        yield return new WaitForSeconds(abilityRegenTime);
        StartCoroutine(regenHealthAbility());
    }

    IEnumerator regenHealthAbility()
    {
        int emptyAbilitiesOnRegen = getEmptyAbilities();

        for (int i = 0; i < emptyAbilitiesOnRegen; i++)
        {
            currentAbilities++;
            yield return new WaitForSeconds(abilityRegenTime); 
        }
    }

    IEnumerator radDamEffect()
    {
        damageEffects[currentHealth].SetBool("RadiationDamageEffect", true);
        yield return new WaitForSeconds(0.01f);
        damageEffects[currentHealth].SetBool("RadiationDamageEffect", false);
    }

    void RadiationDamage()
    {
        if (Mathf.Round(Puddle.Instance.timer) == 2 && Puddle.Instance.isBuffed)
        {
            if(currentHealth > 1)
            {
                currentHealth = healthOnRad - 1;

                radDamageTaken = 1;
            }
        }
        else if(Mathf.Round(Puddle.Instance.timer) == 4 && Puddle.Instance.isBuffed)
        {
            if (currentHealth > 1)
            {
                currentHealth = healthOnRad - 2;

                radDamageTaken = 2;
            }
        }
        //Heal Back Lost Health
        if (Puddle.Instance.isBuffed == false && Mathf.Round(Puddle.Instance.timer) == 2)
        {
            if(radDamageTaken == 2)
            {
                currentHealth = healthOnRad - 1;
            }
            else if(radDamageTaken == 1)
            {
                currentHealth = healthOnRad;
                radDamageTaken = 0;
            }
        }
        else if (Puddle.Instance.isBuffed == false && Mathf.Round(Puddle.Instance.timer) == 0 && radDamageTaken == 2)
        {
            currentHealth = healthOnRad;
            radDamageTaken = 0;
        }
        //Effect Management
        if (currentHealth == healthOnRad)
        {
            for (int i = 0; i < radiationDamageEffects.Length; i++)
            {
                radiationDamageEffects[i].SetBool("RadiationLoop", false);
            }
        }
        else if (currentHealth == (healthOnRad - 1))
        {
            for (int i = 0; i < radiationDamageEffects.Length; i++)
            {
                if (i != (healthOnRad - 1))
                {
                    radiationDamageEffects[i].SetBool("RadiationLoop", false);
                }
                else
                {
                    radiationDamageEffects[i].SetBool("RadiationLoop", true);
                }
            }
        }
        else if (currentHealth == (healthOnRad - 2))
        {
            for (int i = 0; i < radiationDamageEffects.Length; i++)
            {
                if (i != (healthOnRad - 1) && i != (healthOnRad - 2))
                {
                    radiationDamageEffects[i].SetBool("RadiationLoop", false);
                }
                else
                {
                    radiationDamageEffects[i].SetBool("RadiationLoop", true);
                }
            }
        }

    }

    public IEnumerator Heal(int health, float wait)
    {
        if(wait == 0)
        {
            wait = 0.1f;
        }

        if((health + currentHealth) > maxHealth)
        {
            currentHealth = maxHealth;
            yield return null;
        }
        else
        {
            for (int i = 0; i < health; i++)
            {
                if (currentHealth != maxHealth)
                {
                    yield return new WaitForSeconds(wait);
                    damageEffects[currentHealth].SetTrigger("GainHealthPt");
                    currentHealth++;
                }
            }
        }
    }

    void VignetteHealth()
    {
        UnityEngine.Rendering.Universal.Vignette vignette;
        if (!volumeProfile.TryGet(out vignette)) throw new System.NullReferenceException(nameof(vignette));

        float intensity = ((float)currentHealth / maxHealth);
        vignette.intensity.Override(0.2f - (intensity / 4));
    }

    private void OnApplicationQuit()
    {
        UnityEngine.Rendering.Universal.Vignette vignette;
        if (!volumeProfile.TryGet(out vignette)) throw new System.NullReferenceException(nameof(vignette));
        vignette.intensity.Override(0f);
    }

    public void Die()
    {
        damageFlash.SetTrigger("DamageFlash");
        GameObject.FindGameObjectWithTag("CheckpointManager").GetComponent<CheckpointManager>().EndGame();
        healthUIAnimator.SetBool("HealthFade", true);
        StartCoroutine(ResetHealth());
    }

    public IEnumerator ResetHealth()
    {
        healthUIAnimator.SetBool("HealthFade", false);
        yield return new WaitForSeconds(0.5f);
        currentHealth = maxHealth;
    }

}