using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogueTrigger : MonoBehaviour
{
    public static DialogueTrigger Instance { get; private set; }

    public Dialogue dialogue;
    private DialogueManager dm;

    private Text indicatorText;

    private bool inRange = false;
    private bool crosshairInRange = false;

    private void Start()
    {
        indicatorText = GameObject.FindGameObjectWithTag("IndicatorText").GetComponent<Text>();
        dm = GameObject.FindGameObjectWithTag("DialogueManager").GetComponent<DialogueManager>();

        dialogue.isQuestion = new bool[dialogue.sentences.Length];
        dialogue.answers = new bool[dialogue.sentences.Length];

        for (int i = 0; i < dialogue.sentences.Length; i++)
        {
            string sentence = dialogue.sentences[i];
            if(sentence[sentence.Length - 1] == '#')
            {
                dialogue.isQuestion[i] = true;
            }
            else
            {
                dialogue.isQuestion[i] = false;
            }
        }
    }

    public void ChoseAnswer()
    {

        if (dialogue.isQuestion[dm.currentSentence])
        {
            dialogue.answers[dm.currentSentence] = dm.SetAnswer(dialogue.answers[dm.currentSentence]);
        }

    }

    public void TriggerDialogue()
    {
        FindObjectOfType<DialogueManager>().StartDialogue(dialogue);
    }

    private void Update()
    {
        ChoseAnswer();

        if (inRange && crosshairInRange && dm.started == false && dm.canClickBox)
        {
            indicatorText.enabled = true;
        }
        else
        {
            indicatorText.enabled = false;
        }

        if (Input.GetKeyDown(KeyCode.Mouse0) && inRange && crosshairInRange && dm.started == false && dm.canClickBox)
        {
            TriggerDialogue();
        }

        if(dm.started == true)
        {
            if (Input.GetKeyDown(KeyCode.Mouse0) && dm.ynBox.activeSelf == false)
            {
                dm.DisplayNextSentence();
            }
            else if(dm.ynBox.activeSelf && dm.GetHasClicked())
            {
                dm.SetHasClicked(false);
                dm.DisplayNextSentence();
            }
        }

    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Player")
        {
            inRange = true;
        }
        if (collision.gameObject.tag == "Crosshair")
        {
            crosshairInRange = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            inRange = false;
        }
        if (collision.gameObject.tag == "Crosshair")
        {
            crosshairInRange = false;
        }
    }

    

}
